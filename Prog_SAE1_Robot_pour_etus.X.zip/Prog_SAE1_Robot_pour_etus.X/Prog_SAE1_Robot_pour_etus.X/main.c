#include "mcc_generated_files/mcc.h"
#include "drivers/vl53l0x.h"
#include <stdio.h>
#include <string.h>

#include "drivers/LCD.h"
#include <math.h>
#include "commandes.h"

// ces coefficients peuvent �tre modifi�s pour r�gler diff�remment le correcteur de vitesse
// moteur
uint8_t kpm = 40;    
uint8_t kim = 14; 

//uint8_t consigne;

void main(void)//__at 0x00200
{   
    SYSTEM_Initialize();
     
    INTERRUPT_GlobalInterruptEnable();
    INTERRUPT_PeripheralInterruptEnable();
     
    Motors(0);
    Speed_Motors( 0, 0 );

    Buzzer(OFF);
    initLCD();
    clearLCD();
    retroLCD(ON);
    __delay_ms(50);
    
    Ecrit_Valeur_selection(0);
    
    gotoLCD(0,0); printLCD("ROBOT 1 CACHAN  ");
    gotoLCD(1,0); printLCD("   IUT HAGUENAU ");
    __delay_ms(1000);
    clearLCD();
    
    while (1)
    {

    }
}

// tests

// test 1 : OK
// Rajout d'un timer sous interrupyion
// dans l'init, placer :
//      TMR5_SetInterruptHandler(Timer5_5_ms_ISR); 
//      TMR5_StartTimer(); 
// puis rajouter Timer5_5_ms_ISR qui est le "callback" qui sera lanc� p�riodiquement 
//(toutes les 5 secondes)
//      void Timer5_5_ms_ISR(void)
//          {
// 
//          }

// test 2 : OK
// Rajout d'un gestionnaire de liaison s�rie sous interrupyion
// dans l'init, placer :
//      EUSART1_SetRxInterruptHandler(EUSART1_RX_ISR); 
// puis rajouter EUSART1_RX_ISR qui est le "callback qui sera lanc� chaque fois 
// qu'un caract�re sera re�u sur la liaison s�rie.
//      volatile uint8_t rxData;
//      void EUSART1_RX_ISR(void)
//          {
//              rxData = RC1REG;
//              // traitement personnel de la donn�e
//
//          }

// test 3 : OK
// Rajout par scrutation de la detection IR RC5
// il suffit de tester le resultat de la fonction RecvRC5().
// Si celle-ci renvoie 0, c'est qu'un code RC5 a �t� re�u, si c'est 2, ce doit
// �tre qu'il n'y a rien d'�mis, le reste des valeurs correspond � des erreurs
// Pour avoir acc�s au message re�u, rajouter l'acc�s aux varaiable :
// pour utiliser les IR telecommandes
//      extern unsigned long rxCmd_IR;
//      extern unsigned long rxAdr_IR;;
//      extern unsigned long bit_bascul_IR; 
//      extern unsigned long data_IR; 
    
// test 4 : OK
// Mise en route des capteurs Lasers
// dans l'init, placer :
//      VL53L0X_InitDevices();
// puis appeler les fonctions :
//     VL53L0X_Read_Distance_No_Wait(0);
//     VL53L0X_Read_Distance_No_Wait(1);
//     VL53L0X_Read_Distance_No_Wait(2);
// qui retournent un uint16_t.
// Entre 2 appels � un m�me capteur, il faut laisser 25ms.

// test 5 : OK
// Mise en route des capteurs IR de ligne
// dans l'init, rien � placer.
// Tous les capteurs sont utilis�s en analogique.
// par exemple la fonction ADCC_GetSingleConversion(Capteur_Analog_CNY_G_Gauche))
// renvoie le r�sultat de la conversion du capteur le plus � gauche.
// M�me chose avec Capteur_Analog_CNY_G_Gauche), Capteur_Analog_CNY_Gauche),  
// Capteur_Analog_CNY_Centre, Capteur_Analog_CNY_Droite) et
// Capteur_Analog_CNY_D_Droite) ainsi que pour avoir acc�s � la tension d'alimentaion
// Capteur_Analog_ALIM 

// Tout le reste fonctionne comme sur le robot pr�c�dent.