#include "mcc_generated_files/mcc.h"
#include "drivers/vl53l0x.h"
#include <stdio.h>
#include <string.h>

#include "drivers/LCD.h"
#include <math.h>
#include "commandes.h"

// ces coefficients peuvent �tre modifi�s pour r�gler diff�remment le correcteur de vitesse
// moteur
uint8_t kpm = 40;    
uint8_t kim = 14; 

uint8_t consigne;

void main(void)//__at 0x00200
{   
    SYSTEM_Initialize();
     
    INTERRUPT_GlobalInterruptEnable();
    INTERRUPT_PeripheralInterruptEnable();
      
    Motors(0);
    Speed_Motors( 0, 0 );

    Buzzer(OFF);
    initLCD();
    clearLCD();
    retroLCD(ON);
    __delay_ms(50);
    
    Ecrit_Valeur_selection(0);
    
    while (1)
    {

        __delay_ms(5);
    }
}






    